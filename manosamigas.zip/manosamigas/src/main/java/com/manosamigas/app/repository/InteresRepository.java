package com.manosamigas.app.repository;

import com.manosamigas.app.entity.Interes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InteresRepository extends JpaRepository<Interes, Integer> {}
