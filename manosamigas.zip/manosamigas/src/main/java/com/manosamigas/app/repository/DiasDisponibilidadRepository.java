package com.manosamigas.app.repository;

import com.manosamigas.app.entity.DiasDisponibilidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiasDisponibilidadRepository extends JpaRepository<DiasDisponibilidad, Integer> {}
